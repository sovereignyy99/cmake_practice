/**
 * @Author: mp
 * @Date: 2022/4/24 17:02
 * @Last Modified by: mp
 * @Last Modified time: 2022/4/24 17:02
 */

#pragma once

int MyAdd(int a, int b);
